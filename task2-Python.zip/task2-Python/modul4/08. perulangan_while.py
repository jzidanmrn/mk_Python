hitung = 0

while (hitung < 5):
    print("hitung :", hitung)
    hitung = hitung + 1