def sapa(nama):
    "Contoh cetak keterangan"
    print("Hai, " + nama + ". Apa kabar?")
    return nama


sapa("Anna")
print(sapa.__doc__)

