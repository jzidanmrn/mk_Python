nomor = [5, 5, 2]

jumlah = 0

for tampung in nomor:
    jumlah = jumlah + tampung

print("Jumlah semuanya :", jumlah)