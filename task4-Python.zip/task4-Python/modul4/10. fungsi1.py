def sapa(nama):
    print("Hai, " + nama + ". Apa kabar?")
    return nama

# Pemanggilan fungsi
# output Hai, Anna. Apa kabar?
sapa("Anna")