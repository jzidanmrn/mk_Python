def persegipanjang(panjang,lebar):
    luas = panjang * lebar
    print("Luasnya :",luas)
    return luas

print("Menghitung Luas Persegi Panjang")
a = int(input("Masukkan Panjang : "))
b = int(input("Masukkan Lebar : "))
persegipanjang(a,b)