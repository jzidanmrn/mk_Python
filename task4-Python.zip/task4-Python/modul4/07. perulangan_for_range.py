for hitung in range(5):
    print("Hitung :",hitung)