a = 1
b = 2

print(1 is a)
print(2 is b)
print(3 is a)
print(1 is not a)
print(2 is not b)

print(" ")

print(type(a) is int)
print (type(b) is float)