angkal = 2 
a = angkal + 4 + \
    7 +  \
    5

print(a)