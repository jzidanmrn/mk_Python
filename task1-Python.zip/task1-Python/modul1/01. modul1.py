# contoh benar
print("BARIS") 
print("INDENTASI")