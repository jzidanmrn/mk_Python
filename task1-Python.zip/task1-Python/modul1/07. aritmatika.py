a = 43
b = 2

c = a / b
d = a ** b
e = a // b
print("Hasil : ", c)
print("Pangkat : ", d)
print("Hasil : ", e)