kutip1 = 'BELAJAR PYTHON'
kutip2 = "BELAJAR PYTHONDASAR"
kutip3 = """BELAJAR PYTHON
SIANG MALAM"""

print(kutip1)
print(kutip2)
print(kutip3)