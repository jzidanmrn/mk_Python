# output
# Hai Sistem
# Hai Informasi
nama = ('Sistem', 'Informasi')
for a in nama:
    print("Hai", a)