tuple1 = (1,2,3,'a','b','c')

print(3 in tuple1)

print('2' in tuple1)

print('e' in tuple1)

print('k' not in tuple1)
