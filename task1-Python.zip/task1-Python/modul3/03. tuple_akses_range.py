tuple1 = ('p','r','o','g','r','a','m','m','i','n','g')

print(tuple1[:3])

print(tuple1[2:6])

print(tuple1[3:])
