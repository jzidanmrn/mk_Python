# set integer
set_saya = {1,2,3}
print(set_saya)

set_saya = set([1,2,3])
print(set_saya)

set_saya = {1,2,2,3,3,3}
print(set_saya)

set_saya = {1,2,[3,4,5]}

