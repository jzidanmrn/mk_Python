set_saya = {1,2,3,4,5}
print(set_saya)

set_saya.discard(4)
print(set_saya)

set_saya.remove(5)
print(set_saya)

set_saya.discard(6)