A = {1,2,3,4,5}
B = {4,5,6,7,8}

print(A ^ B)

A.symmetric_difference(B)

print(B ^ A)

B.symmetric_difference(A)