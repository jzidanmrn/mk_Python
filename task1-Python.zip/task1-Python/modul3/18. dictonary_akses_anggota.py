dict_saya = {'nama':'Budi', 'usia':27}

print(dict_saya['nama'])

print(dict_saya.get('usia'))
print(dict_saya.get('alamat'))
