tuple1 = ('p','y','t','h','o','n','s','a','y','a')

print(tuple1.count('a'))

print(tuple1.index('n'))
