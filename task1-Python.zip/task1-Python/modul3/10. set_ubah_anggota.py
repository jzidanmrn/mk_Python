set_saya = {1,2,3}
print(set_saya)

set_saya.add(4)
print(set_saya)

set_saya.update([3,4,5,6])
print(set_saya)