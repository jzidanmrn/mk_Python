kata = "Hello world"
print(kata.count("o"))
print(kata.upper())
print(kata.lower())

kata_baru = kata.split(" ")
print(kata_baru)