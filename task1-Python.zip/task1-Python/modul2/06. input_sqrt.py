# Fungsi sqrt() statis
import math

c = math.sqrt(36)
print(c)

# Fungsi sqrt() dinamis
a =  input("Masukkan Nilai : ")

c = math.sqrt(int(a))
print(c)