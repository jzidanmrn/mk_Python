namaHari = ['Senin', 'Selasa', 'Rabu', 'Kamis']
print(namaHari)


# Bisa juga seperti ini
# namaHari = ['Senin', 'Selasa', 
# 'Rabu', 'Kamis'
# ]
# print(namaHari)