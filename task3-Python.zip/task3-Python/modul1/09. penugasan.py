a = 10
b = 3

a += b
print(a)

a = 10
b = 3

a -= b
print(a)