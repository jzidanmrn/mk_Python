# Fungsi pow() statis
c = pow(2,3)
print(c)

# Fungsi pow() dinamis
a = int(input("Masukkan Nilai : "))
b = int(input("Masukkan Nilai Pangkat : "))

c = pow(a,b)
print(c)