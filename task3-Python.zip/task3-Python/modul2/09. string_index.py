kata = "Hello world"
print(kata.index("o"))