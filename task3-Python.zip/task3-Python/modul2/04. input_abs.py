# Fungsi abs() statis
a = -5

c = abs(a)
print(c)

# Fungsi abs() dinamis
a =  int(input("Masukkan Nilai A : "))

c = abs(a)
print(c)