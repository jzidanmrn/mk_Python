alfabet = ['a','c','d','e','b']
alfabet.reverse()
print(alfabet)
# output ['b','e','d','c','a']