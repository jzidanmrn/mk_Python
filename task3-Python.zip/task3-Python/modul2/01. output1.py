print(1, 3, 5, 7)
# output: 1 3 5 7

print(1,2,3,4, sep='*')
# output: 1*2*3*4

print(1,2,3,4, sep='#', end='&')
# output: 1#2#3#4&
