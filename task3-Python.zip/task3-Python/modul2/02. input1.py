# Contoh kode input
a =  int(input("Masukkan Nilai A : "))
b =  int(input("Masukkan Nilai B : "))

print(a,b)

# Contoh kode input integer tanpa fungsi int()
a =  input("Masukkan Nilai A : ")
b =  input("Masukkan Nilai B : ")

c = a + b
print(c)

# Fungsi int() cara pertama
a =  int(input("Masukkan Nilai A : "))
b =  int(input("Masukkan Nilai B : "))

c = a + b
print(c)

# Fungsi int() cara kedua
a =  input("Masukkan Nilai A : ")
b =  input("Masukkan Nilai B : ")

c = int(a) + int(b)
print(c)
