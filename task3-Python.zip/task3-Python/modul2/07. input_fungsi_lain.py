import math

print(max(2,1,5)) #hasil outputnya = 5

print(min(2,1,5)) #hasil outputnya = 1

print(round(5.8)) #hasil outputnya = 6

print(math.floor(5.8)) #hasil outputnya = 5

print(math.ceil(5.8)) #hasil outputnya = 6
