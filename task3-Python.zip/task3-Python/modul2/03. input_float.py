a =  input("Masukkan Nilai A : ")
b =  input("Masukkan Nilai B : ")

c = float(a) / float(b)
print(c)
