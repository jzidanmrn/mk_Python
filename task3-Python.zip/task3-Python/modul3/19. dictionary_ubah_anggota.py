dict_saya = {'nama':'Ikhsan', 'usia':35}

dict_saya['usia'] = 36
print(dict_saya)

dict_saya['alamat'] = 'Tanjungpinang'
print(dict_saya)