set_saya = set("HelloPython")
print(set_saya)

print(set_saya.pop())
print(set_saya)

print(set_saya.pop())
print(set_saya)

set_saya.clear()
print(set_saya)
