a = {}
print(type(a))

a = set()
print(type(a))