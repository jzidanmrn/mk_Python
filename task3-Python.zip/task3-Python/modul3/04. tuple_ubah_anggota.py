tuple1 = (2, 3, 4, [5, 6])

tuple1[3][0] = 7
print(tuple1)

tuple1 = ('p','y','t','h','o','n')
print(tuple1)

del tuple1
print(tuple1)
# akan terjadi NameError karena tuple1 telah dihapus