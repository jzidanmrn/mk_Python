dict1 = {}
print(dict1)

dict1 = {1 : 'sepatu', 2: 'tas'}
print(dict1)

dict1 = {'warna':'merah', 1:[2,3,5]}
print(dict1)

dict1 = dict([('1', 'sepatu'),('2', 'bola')])
print(dict1)

dict1 = dict(m=8, n=9, o=10)
print(dict1)
