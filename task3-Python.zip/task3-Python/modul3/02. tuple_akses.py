tuple1 = ('p','y','t','h','o','n')
print(tuple1[0])

print(tuple1[1])

print(tuple1[-1])

print(tuple1[-2])

#print(tuple1[6])
